from stem import CircStatus
from stem.control import Controller
import stem.control
import requests

def build_custom_circuit(controller, relay_fingerprints):
    '''
    relay_fingerprints: list of relay fingerprints
    controller: stem.control.Controller object which is used to control tor
    This function helps to build a custom tor circuit using the given relay_fingerprints and then subsequently returns the circuit_id of the newly created circuit to identify the circuit.
    '''
    circuit_id = controller.new_circuit(path=relay_fingerprints, await_build=True)
    return circuit_id

def get(url="http://ifconfig.io/ip",port=9000):
    '''
    used to fetch the data from the given url using the tor circuit
    '''
    res = requests.get(url, proxies={'http': f'socks4://127.0.0.1:{port}'})
    print(res.text)

def attach_stream(stream):
    '''
    making the stream (i.e. the tcp connections that we will generate) to attach to the custom circuit
    '''
    if stream.status == 'NEW':
        controller.attach_stream(stream.id, circuit_id)

def get_url(controller, circuit_id, url, socksPort):
    # add_event_listener is used to attach the stream to the custom circuit, thereby whenever any action happens such as new tcp connection, it will be attached to the custom circuit by calling the attach_stream function
    controller.add_event_listener(attach_stream, stem.control.EventType.STREAM)
    #ensures that the streams are not attached to any circuit by default and we can attach them to the custom circuit
    controller.set_conf('__LeaveStreamsUnattached', '1') 
    # get the url using the custom circuit
    get(url, socksPort)
    # remove the event listener and reset the configuration
    controller.remove_event_listener(attach_stream)
    controller.reset_conf('__LeaveStreamsUnattached')


if __name__ == "__main__":
    with Controller.from_port(port=9051) as controller:
        controller.authenticate()

        # First we create the custom circuit by getting the circuit size and the fingerprints of the relays
        # Specify the fingerprints of the desired relays
        relay_fingerprints = [] # ["FINGERPRINT1", "FINGERPRINT2", "FINGERPRINT3"]
        numRelays = int(input("enter number of relays: "))
        for i in range(numRelays):
            relay_fingerprints.append(input("enter fingerprint: "))

        # Build the custom circuit
        circuit_id = build_custom_circuit(controller, relay_fingerprints)

        # Print the details of the custom circuit
        print(f"Custom Circuit ID: {circuit_id}")
        for circ in controller.get_circuits():
            if circ.id == circuit_id:
                print("Custom Circuit Path:")
                for i, entry in enumerate(circ.path):
                    div = '+' if (i == len(circ.path) - 1) else '|'
                    fingerprint, nickname = entry
                    desc = controller.get_network_status(fingerprint, None)
                    address = desc.address if desc else 'unknown'
                    print(f" {div}- {fingerprint} ({nickname}, {address})")

        url = "http://ifconfig.io/ip"
        socksPort = 9000
        # Get the URL using the custom circuit
        get_url(controller, circuit_id, url, socksPort)
        controller.close()